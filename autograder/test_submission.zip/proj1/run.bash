#!/bin/bash
set -e -x
g++ main.cpp -o main
./main $*
