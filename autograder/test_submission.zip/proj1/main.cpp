#include <iostream>

void count_to_ten()
{
    std::cout << "I will now count to ten (with zero-indexed values)" << std::endl;
    for (int i = 0; i < 10; i++)
    {
        std::cout << "i = " << i << std::endl;
    }
}

int main(int argc, char** argv)
{
    // Ask the user to enter a name
    std::cout << "Hello, what is your name?" << std::endl;
    std::cout << "> ";
    std::string name;
    std::cin >> name;

    // Greet the user
    std::cout << "Hi, " << name << ", the arguments you passed in were:" << std::endl;
    for (int i = 1; i < argc; i++)
    {
        std::cout << "arg " << i << " = " << argv[i] << std::endl;
    }

    // Skip a line, then count to ten
    std::cout << std::endl;
    count_to_ten();

    // Say goodbye
    std::cout << "Thanks for stopping by. Have a nice day!" << std::endl;
}
